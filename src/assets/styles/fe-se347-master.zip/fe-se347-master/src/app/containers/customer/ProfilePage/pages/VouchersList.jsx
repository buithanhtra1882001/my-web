import React from 'react'

function VouchersList() {
  return (
    <div>VouchersList</div>
  )
}

export default VouchersList