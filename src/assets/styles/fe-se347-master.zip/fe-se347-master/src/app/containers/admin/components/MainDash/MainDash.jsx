import styled from "styled-components"
import tw from "twin.macro"

export const MainDash = styled.div`
  ${tw` flex flex-col justify-start space-y-5 p-5`}
` 