
export let listMenu = [
  {
    name: "Trang chủ",
    subMenu: [
    ],
    path: "/"
  },
  {
    name: "Sản phẩm",
    subMenu: [
    ],
    path: "/product"
  },
  {
    name: "Giới thiệu",
    subMenu: [
    ],
    path: "/product"
  },
  {
    name: "Liên hệ",
    subMenu: [
    ],
    path: "/product"
  },
  {
    name: "Blog",
    subMenu: [
    ],
    path: "/product"
  },
  {
    name: "Tra cứu đơn hàng",
    subMenu: [
    ],
    path: "/product"
  },
  {
    name: "Theo dõi đơn hàng",
    subMenu: [
    ],
    path: "/product"
  },
];
