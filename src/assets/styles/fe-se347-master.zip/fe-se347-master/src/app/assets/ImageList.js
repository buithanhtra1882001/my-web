export const ImageList = [
    './images/Rose.jpg',
    './images/Lisa.jpg',
    './images/Jennie.jpg',
    './images/Jisoo.jpg'
]